package tests;
import model.*;
import view.*;
import javax.swing.*;

import controller.MapController;

import java.awt.*;
import java.util.Iterator;
import java.util.Set;

public class TestHexMap {
/*
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MapController mc = new MapController(100,100, null);
		JFrame f = new JFrame("HexMap");
		

		
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				
		MapDrawer ui = new MapDrawer(mc.hexmap);
		
		f.add(ui);
		f.setSize(1920,1080); 
		f.setVisible(true);

		System.out.println(mc.printString());



	}
	
*/
}
