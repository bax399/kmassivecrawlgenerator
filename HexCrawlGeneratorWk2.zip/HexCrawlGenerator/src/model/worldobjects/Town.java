package model.worldobjects;
import java.util.*;
public class Town {

}
