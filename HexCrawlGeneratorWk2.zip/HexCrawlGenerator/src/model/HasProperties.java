package model;
import java.util.*;
public interface HasProperties
{
	public void processProperties(Properties props);
	public String getName();
	public String getDescription();
}
