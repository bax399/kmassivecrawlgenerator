package model;
public class RiverNetwork extends Connection {
	public RiverNetwork(FilledHex v1, FilledHex v2, int weight)
	{
		super(v1, v2, weight);
	}	
}
