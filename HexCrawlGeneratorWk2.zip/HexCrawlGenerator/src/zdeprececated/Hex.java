package zdeprececated;
import model.graphresource.*;
public class Hex extends Vertex{
	public Hex(int uniqueid)
	{
		super(uniqueid);
	}
	
}
